$('.slider_main').slick({
    autoplay: true,
    arrows: false,
    autoplaySpeed: 2500,
    dots: true,
    slidesToShow: 1,
});