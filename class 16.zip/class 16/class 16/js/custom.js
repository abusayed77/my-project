$('.slider_main').slick({
	autoplay: true,
	arrows: false,
	dots: true,
	slidesToShow: 1,
	slidesToScroll: 1,
});


$('.banner-slider').slick({
	arrows: false,
	autoplay: true,
	dots: true,
	slidesToShow: 1,
	slidesToScroll: 1,
});